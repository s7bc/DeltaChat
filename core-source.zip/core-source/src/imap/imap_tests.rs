use super::*;
use crate::test_utils::TestContext;

impl SessionStream for tokio::io::DuplexStream {
    fn set_read_timeout(&mut self, _timeout: Option<Duration>) {}

    fn peer_addr(&self) -> Result<std::net::SocketAddr> {
        anyhow::bail!("An in-memory IMAP test peer has no network address")
    }
}

/// An in-memory IMAP peer records every wire command, including unexpected folder access.
async fn folder_test_session(
    allowed_folder: Option<&str>,
) -> Result<(Session, tokio::task::JoinHandle<Vec<String>>)> {
    use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
    let (stream, peer) = tokio::io::duplex(8192);
    let server = tokio::spawn(async move {
        let mut peer = BufReader::new(peer);
        peer.write_all(b"* OK test server\r\n").await.unwrap();
        let mut commands = Vec::new();
        loop {
            let mut line = String::new();
            if peer.read_line(&mut line).await.unwrap() == 0 {
                break;
            }
            let tag = line.split_whitespace().next().unwrap().to_owned();
            let response = if line.contains(" SELECT ") {
                format!(
                    "* 0 EXISTS\r\n* OK [UIDVALIDITY 7] valid\r\n* OK [UIDNEXT 1] next\r\n{tag} OK selected\r\n"
                )
            } else if line.contains(" LOGIN ") {
                format!("{tag} OK logged in\r\n")
            } else {
                format!("{tag} BAD unexpected command\r\n")
            };
            commands.push(line);
            peer.write_all(response.as_bytes()).await.unwrap();
        }
        commands
    });
    let stream: Box<dyn SessionStream> = Box::new(stream);
    let mut client = async_imap::Client::new(stream);
    client.read_response().await?.context("Missing greeting")?;
    let inner = client.login("test", "test").await.map_err(|(err, _)| err)?;
    let (sender, _) = async_channel::bounded(1);
    let session = Session::new(
        inner,
        capabilities::Capabilities {
            can_idle: false,
            can_check_quota: false,
            can_metadata: false,
            can_compress: false,
            server_id: None,
        },
        sender,
        1,
        allowed_folder.map(str::to_owned),
    );
    Ok((session, server))
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_strict_folder_blocks_other_folders_on_wire() -> Result<()> {
    let t = TestContext::new_alice().await;
    let (mut session, server) = folder_test_session(Some("Mail/Chat")).await?;
    for folder in ["INBOX", "Sent", "Drafts", "DeltaChat", "mail/chat"] {
        assert!(session.select_with_uidvalidity(&t, folder).await.is_err());
    }
    assert!(session.select_with_uidvalidity(&t, "Mail/Chat").await?);
    drop(session);
    let commands = server.await?;
    assert_eq!(commands.len(), 2, "Unexpected IMAP commands: {commands:?}");
    assert!(commands[1].contains("SELECT \"Mail/Chat\""));
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_strict_folder_skips_old_downloads_and_seen_flags() -> Result<()> {
    let t = TestContext::new_alice().await;
    let bob = TestContext::new_bob().await;
    let chat = t.create_chat(&bob).await;
    let sent = t.send_text(chat.id, "Previously partial download").await;
    let msg = t.get_last_msg().await;
    msg.id
        .update_download_state(&t, crate::download::DownloadState::Available)
        .await?;
    msg.id.download_full(&t).await?;
    let (_, mut param) = ConfiguredLoginParam::load_all(&t).await?.remove(0);
    param.imap_folder = Some("Mail/Chat".into());
    param
        .save_to_transports_table(&t, &crate::login_param::EnteredLoginParam::default(), 0)
        .await?;
    let (mut session, server) = folder_test_session(Some("Mail/Chat")).await?;
    t.sql.execute(
        "INSERT INTO imap (id, transport_id, rfc724_mid, folder, uid, uidvalidity, target) VALUES (101, 1, ?, 'INBOX', 7, 1, 'INBOX')",
        (msg.rfc724_mid(),),
    ).await?;
    t.sql
        .execute("INSERT INTO imap_markseen (id) VALUES (101)", ())
        .await?;
    session.store_seen_flags_on_imap(&t).await?;
    assert!(
        crate::download::download_msg(&t, msg.rfc724_mid().into(), &mut session)
            .await?
            .is_none()
    );
    assert_eq!(
        Message::load_from_db(&t, msg.id).await?.download_state(),
        crate::download::DownloadState::Failure
    );
    assert_eq!(t.sql.count("SELECT COUNT(*) FROM download", ()).await?, 0);
    drop(sent);
    drop(session);
    let commands = server.await?;
    assert_eq!(commands.len(), 1, "Old folder accessed: {commands:?}");
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_strict_folder_inbox_case_and_default_behavior() -> Result<()> {
    let t = TestContext::new_alice().await;
    let (mut session, server) = folder_test_session(Some("INBOX")).await?;
    assert!(session.select_with_uidvalidity(&t, "inbox").await?);
    assert!(
        session
            .select_with_uidvalidity(&t, "Inbox/Child")
            .await
            .is_err()
    );
    drop(session);
    assert_eq!(server.await?.len(), 2);

    let (mut session, server) = folder_test_session(None).await?;
    assert!(session.select_with_uidvalidity(&t, "Sent").await?);
    drop(session);
    assert_eq!(server.await?.len(), 2);
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_set_uid_next_validity() {
    let t = TestContext::new_alice().await;
    assert_eq!(get_uid_next(&t.ctx, 1, "Inbox").await.unwrap(), 0);
    assert_eq!(get_uidvalidity(&t.ctx, 1, "Inbox").await.unwrap(), 0);

    set_uidvalidity(&t.ctx, 1, "Inbox", 7).await.unwrap();
    assert_eq!(get_uidvalidity(&t.ctx, 1, "Inbox").await.unwrap(), 7);
    assert_eq!(get_uid_next(&t.ctx, 1, "Inbox").await.unwrap(), 0);

    // For another transport there is still no UIDVALIDITY set.
    assert_eq!(get_uidvalidity(&t.ctx, 2, "Inbox").await.unwrap(), 0);

    set_uid_next(&t.ctx, 1, "Inbox", 5).await.unwrap();
    set_uidvalidity(&t.ctx, 1, "Inbox", 6).await.unwrap();
    assert_eq!(get_uid_next(&t.ctx, 1, "Inbox").await.unwrap(), 5);
    assert_eq!(get_uidvalidity(&t.ctx, 1, "Inbox").await.unwrap(), 6);

    assert_eq!(get_uid_next(&t.ctx, 2, "Inbox").await.unwrap(), 0);
    assert_eq!(get_uidvalidity(&t.ctx, 2, "Inbox").await.unwrap(), 0);
}

#[test]
fn test_build_sequence_sets() {
    assert_eq!(build_sequence_sets(&[]).unwrap(), vec![]);

    let cases = vec![
        (vec![1], "1"),
        (vec![3291], "3291"),
        (vec![1, 3, 5, 7, 9, 11], "1,3,5,7,9,11"),
        (vec![1, 2, 3], "1:3"),
        (vec![1, 4, 5, 6], "1,4:6"),
        ((1..=500).collect(), "1:500"),
        (vec![3, 4, 8, 9, 10, 11, 39, 50, 2], "3:4,8:11,39,50,2"),
    ];
    for (input, s) in cases {
        assert_eq!(
            build_sequence_sets(&input).unwrap(),
            vec![(input, s.into())]
        );
    }

    let has_number = |(uids, s): &(Vec<u32>, String), number| {
        uids.contains(&number) && s.split(',').any(|n| n.parse::<u32>().unwrap() == number)
    };

    let numbers: Vec<_> = (2..=500).step_by(2).collect();
    let result = build_sequence_sets(&numbers).unwrap();
    for (_, set) in &result {
        assert!(set.len() < 1010);
        assert!(!set.ends_with(','));
        assert!(!set.starts_with(','));
    }
    assert!(result.len() == 1); // these UIDs fit in one set
    for &number in &numbers {
        assert!(result.iter().any(|r| has_number(r, number)));
    }

    let numbers: Vec<_> = (1..=1000).step_by(3).collect();
    let result = build_sequence_sets(&numbers).unwrap();
    for (_, set) in &result {
        assert!(set.len() < 1010);
        assert!(!set.ends_with(','));
        assert!(!set.starts_with(','));
    }
    let (last_uids, last_str) = result.last().unwrap();
    assert_eq!(
        last_uids.get((last_uids.len() - 2)..).unwrap(),
        &[997, 1000]
    );
    assert!(last_str.ends_with("997,1000"));
    assert!(result.len() == 2); // This time we need 2 sets
    for &number in &numbers {
        assert!(result.iter().any(|r| has_number(r, number)));
    }

    let numbers: Vec<_> = (30000000..=30002500).step_by(4).collect();
    let result = build_sequence_sets(&numbers).unwrap();
    for (_, set) in &result {
        assert!(set.len() < 1010);
        assert!(!set.ends_with(','));
        assert!(!set.starts_with(','));
    }
    assert_eq!(result.len(), 6);
    for &number in &numbers {
        assert!(result.iter().any(|r| has_number(r, number)));
    }
}

#[test]
fn test_uid_grouper() {
    // Input: sequence of (rowid: i64, uid: u32, target: String)
    // Output: sequence of (target: String, rowid_set: Vec<i64>, uid_set: String)
    let grouper = UidGrouper::from([(1, 2, "INBOX".to_string())]);
    let res: Vec<(String, Vec<i64>, String)> = grouper.into_iter().collect();
    assert_eq!(res, vec![("INBOX".to_string(), vec![1], "2".to_string())]);

    let grouper = UidGrouper::from([(1, 2, "INBOX".to_string()), (2, 3, "INBOX".to_string())]);
    let res: Vec<(String, Vec<i64>, String)> = grouper.into_iter().collect();
    assert_eq!(
        res,
        vec![("INBOX".to_string(), vec![1, 2], "2:3".to_string())]
    );

    let grouper = UidGrouper::from([
        (1, 2, "INBOX".to_string()),
        (2, 2, "INBOX".to_string()),
        (3, 3, "INBOX".to_string()),
    ]);
    let res: Vec<(String, Vec<i64>, String)> = grouper.into_iter().collect();
    assert_eq!(
        res,
        vec![("INBOX".to_string(), vec![1, 2, 3], "2:3".to_string())]
    );
}
