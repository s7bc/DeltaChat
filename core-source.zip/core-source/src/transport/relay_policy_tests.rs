//! Regression tests for independent relay encryption policies.

use anyhow::Result;

use super::{
    ConfiguredLoginParam, ConfiguredLoginParamJson, add_pseudo_transport,
    all_transports_require_encryption, eligible_smtp_transports, sync_relay_encryption_policies,
    sync_transports, transport_requires_encryption,
};
use crate::chat::{ChatId, send_text_msg};
use crate::config::Config;
use crate::contact::Contact;
use crate::download::DownloadState;
use crate::ephemeral::{delete_expired_imap_messages, should_delete_all_downloaded_messages};
use crate::imap::prefetch_should_download_for_transport;
use crate::login_param::EnteredLoginParam;
use crate::message::{Message, MessageState, rfc724_mid_exists};
use crate::receive_imf::receive_imf_for_transport;
use crate::smtp::{Smtp, send_msg_to_smtp};
use crate::sync::{RelayEncryptionPolicy, TransportData};
use crate::test_utils::{TestContext, encrypt_raw_message};
use crate::tools::time;

async fn relay_id(t: &TestContext, addr: &str) -> Result<u32> {
    Ok(t.sql
        .query_get_value("SELECT id FROM transports WHERE addr=?", (addr,))
        .await?
        .expect("test relay exists"))
}

/// Changes the fixture without running real IMAP/SMTP configuration.
async fn set_policy(t: &TestContext, id: u32, force: bool) -> Result<()> {
    t.sql
        .execute(
            "UPDATE transports SET
                entered_param=json_set(entered_param, '$.force_encryption', json(?1)),
                configured_param=json_set(configured_param, '$.force_encryption', json(?1))
             WHERE id=?2",
            (if force { "true" } else { "false" }, id),
        )
        .await?;
    Ok(())
}

async fn mixed_relays() -> Result<(TestContext, u32, u32)> {
    let t = TestContext::new_alice().await;
    add_pseudo_transport(&t, "alice@mail.example.org").await?;
    let strict = relay_id(&t, "alice@example.org").await?;
    let mail = relay_id(&t, "alice@mail.example.org").await?;
    set_policy(&t, strict, true).await?;
    set_policy(&t, mail, false).await?;
    Ok((t, strict, mail))
}

fn plaintext(mid: &str, body: &str) -> Vec<u8> {
    format!(
        "From: Bob <bob@example.net>\r\n\
         To: alice@example.org, alice@mail.example.org\r\n\
         Message-ID: <{mid}>\r\n\
         Date: Wed, 30 Sep 2026 12:00:00 +0000\r\n\
         MIME-Version: 1.0\r\n\
         Content-Type: text/plain; charset=utf-8\r\n\
         \r\n{body}\r\n"
    )
    .into_bytes()
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_relay_policy_rejected_copy_does_not_block_allowed_copy() -> Result<()> {
    let (t, strict, mail) = mixed_relays().await?;
    let mid = "relay-policy-copy@example.net";
    let raw = plaintext(mid, "Ordinary mail on the permitted relay");

    assert!(
        receive_imf_for_transport(&t, strict, mid, &raw, false)
            .await?
            .is_none()
    );
    t.assert_warn("Fetched unencrypted message, ignoring").await;
    // In particular, the strict relay must not create a global TRASH tombstone:
    // the same mail can legitimately arrive through the second relay later.
    assert_eq!(rfc724_mid_exists(&t, mid).await?, None);

    let received = receive_imf_for_transport(&t, mail, mid, &raw, false)
        .await?
        .expect("the mail relay accepts ordinary mail");
    assert!(!received.chat_id.is_special());
    let msg_id = *received.msg_ids.last().expect("a visible message");
    let message = Message::load_from_db(&t, msg_id).await?;
    assert!(
        message
            .get_text()
            .contains("Ordinary mail on the permitted relay")
    );

    // A later rejected copy must not remove or reassign the already accepted mail.
    assert!(
        receive_imf_for_transport(&t, strict, mid, &raw, false)
            .await?
            .is_none()
    );
    t.assert_warn("Fetched unencrypted message, ignoring").await;
    assert_eq!(rfc724_mid_exists(&t, mid).await?, Some(msg_id));
    assert_eq!(
        Message::load_from_db(&t, msg_id).await?.get_chat_id(),
        received.chat_id
    );
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_relay_policy_prefetch_uses_each_relays_setting() -> Result<()> {
    let (t, strict, mail) = mixed_relays().await?;
    let mid = "prefetch-plain@example.net";
    let raw = plaintext(mid, "Ordinary mail");
    let headers = mailparse::parse_mail(&raw)?.headers;
    for (id, expected) in [(strict, false), (mail, true)] {
        assert_eq!(
            prefetch_should_download_for_transport(&t, id, &headers, mid, std::iter::empty(),)
                .await?,
            expected
        );
    }
    let raw = b"From: bob@example.net\r\n\
                To: alice@example.org\r\n\
                Content-Type: multipart/encrypted; protocol=\"application/pgp-encrypted\"\r\n\r\n";
    let headers = mailparse::parse_mail(raw)?.headers;
    for id in [strict, mail] {
        assert!(
            prefetch_should_download_for_transport(
                &t,
                id,
                &headers,
                "prefetch-encrypted@example.net",
                std::iter::empty(),
            )
            .await?
        );
    }
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_relay_policy_encrypted_chat_stays_encrypted_on_either_relay() -> Result<()> {
    let (t, strict, mail) = mixed_relays().await?;
    let bob = TestContext::new_bob().await;
    for transport_id in [strict, mail] {
        let mid = format!("encrypted-on-{transport_id}@example.net");
        let raw = encrypt_raw_message(&bob, &[&t], &plaintext(&mid, "Encrypted hello")).await?;
        let received = receive_imf_for_transport(&t, transport_id, &mid, raw.as_bytes(), false)
            .await?
            .expect("both relay policies allow encrypted messages");
        let msg_id = *received.msg_ids.last().unwrap();
        assert!(Message::load_from_db(&t, msg_id).await?.get_showpadlock());
        received.chat_id.accept(&t).await?;
        let reply_id = send_text_msg(&t, received.chat_id, "Encrypted reply".into()).await?;
        assert!(Message::load_from_db(&t, reply_id).await?.get_showpadlock());
        assert_eq!(
            t.sql
                .query_get_value::<bool>(
                    "SELECT is_encrypted FROM smtp2 WHERE msg_id=?",
                    (reply_id,),
                )
                .await?,
            Some(true),
            "permitting ordinary mail does not downgrade an encrypted chat"
        );
    }
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_relay_policy_enabling_encryption_preserves_existing_mail() -> Result<()> {
    let (t, _, mail) = mixed_relays().await?;
    let before_mid = "relay-policy-before@example.net";
    let before = plaintext(before_mid, "Previously received mail");
    let received = receive_imf_for_transport(&t, mail, before_mid, &before, false)
        .await?
        .expect("ordinary mail is initially allowed");
    let msg_id = *received.msg_ids.last().unwrap();

    set_policy(&t, mail, true).await?;
    assert!(all_transports_require_encryption(&t).await?);
    let after_mid = "relay-policy-after@example.net";
    let after = plaintext(after_mid, "New ordinary mail");
    assert!(
        receive_imf_for_transport(&t, mail, after_mid, &after, false)
            .await?
            .is_none()
    );
    t.assert_warn("Fetched unencrypted message, ignoring").await;
    assert_eq!(rfc724_mid_exists(&t, after_mid).await?, None);
    assert!(
        Message::load_from_db(&t, msg_id)
            .await?
            .get_text()
            .contains("Previously received mail")
    );

    // Switching the option back permits the previously rejected mail as well.
    set_policy(&t, mail, false).await?;
    assert!(
        receive_imf_for_transport(&t, mail, after_mid, &after, false)
            .await?
            .is_some()
    );
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_relay_policy_is_independent_and_persisted() -> Result<()> {
    let (t, strict, mail) = mixed_relays().await?;
    assert!(transport_requires_encryption(&t, strict).await?);
    assert!(!transport_requires_encryption(&t, mail).await?);
    assert!(!all_transports_require_encryption(&t).await?);

    for (id, configured) in ConfiguredLoginParam::load_all(&t).await? {
        assert_eq!(configured.force_encryption, id == strict);
        let entered_json: String = t
            .sql
            .query_get_value("SELECT entered_param FROM transports WHERE id=?", (id,))
            .await?
            .unwrap();
        let entered: EnteredLoginParam = serde_json::from_str(&entered_json)?;
        assert_eq!(entered.force_encryption, id == strict);
    }

    // The compatibility setter still has its historical account-wide meaning.
    t.set_config_bool(Config::ForceEncryption, true).await?;
    assert!(transport_requires_encryption(&t, strict).await?);
    assert!(transport_requires_encryption(&t, mail).await?);
    assert!(all_transports_require_encryption(&t).await?);
    t.set_config_bool(Config::ForceEncryption, false).await?;
    assert!(!transport_requires_encryption(&t, strict).await?);
    assert!(!transport_requires_encryption(&t, mail).await?);
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_relay_policy_invalid_boolean_cannot_disable_encryption() -> Result<()> {
    let (t, strict, mail) = mixed_relays().await?;
    for value in ["invalid", "", "-1", "2", "true", "false"] {
        assert!(
            t.set_config(Config::ForceEncryption, Some(value))
                .await
                .is_err()
        );
        assert!(transport_requires_encryption(&t, strict).await?);
        assert!(!transport_requires_encryption(&t, mail).await?);
    }
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_relay_policy_server_retention_uses_receiving_relay() -> Result<()> {
    let (t, strict, mail) = mixed_relays().await?;
    t.set_config_bool(Config::BccSelf, false).await?;
    assert!(should_delete_all_downloaded_messages(&t, strict).await?);
    assert!(!should_delete_all_downloaded_messages(&t, mail).await?);
    let now = time();
    for (uid, mid, encrypted, expires) in [
        (1_u32, "retained-mail@example.net", false, 0),
        (2, "downloaded-encrypted@example.net", true, 0),
        (3, "expired-mail@example.net", false, now - 60),
    ] {
        t.sql
            .execute(
                "INSERT INTO msgs (rfc724_mid,timestamp,ephemeral_timestamp,download_state,param)
                 VALUES (?,?,?,?,?)",
                (
                    mid,
                    now,
                    expires,
                    DownloadState::Done,
                    if encrypted { "c=1" } else { "" },
                ),
            )
            .await?;
        for transport_id in [strict, mail] {
            t.sql
                .execute(
                    "INSERT INTO imap (transport_id,rfc724_mid,folder,uid,target,uidvalidity)
                     VALUES (?,?,'INBOX',?,'INBOX',1)",
                    (transport_id, mid, uid),
                )
                .await?;
        }
    }

    delete_expired_imap_messages(&t, strict).await?;
    assert_eq!(
        t.sql
            .count(
                "SELECT COUNT(*) FROM imap WHERE transport_id=? AND target=''",
                (strict,)
            )
            .await?,
        3
    );
    assert_eq!(
        t.sql
            .count(
                "SELECT COUNT(*) FROM imap WHERE transport_id=? AND target='INBOX'",
                (mail,)
            )
            .await?,
        3,
        "the strict relay's cleanup must not affect another relay"
    );
    delete_expired_imap_messages(&t, mail).await?;
    let remaining: Vec<String> = t
        .sql
        .query_map_vec(
            "SELECT rfc724_mid FROM imap WHERE transport_id=? AND target='INBOX'",
            (mail,),
            |row| Ok(row.get(0)?),
        )
        .await?;
    assert_eq!(remaining, vec!["retained-mail@example.net"]);

    t.set_config_bool(Config::BccSelf, true).await?;
    assert!(!should_delete_all_downloaded_messages(&t, strict).await?);
    assert!(!should_delete_all_downloaded_messages(&t, mail).await?);
    t.sql.execute("UPDATE imap SET target='INBOX'", ()).await?;
    for transport_id in [strict, mail] {
        delete_expired_imap_messages(&t, transport_id).await?;
        assert_eq!(
            t.sql
                .count(
                    "SELECT COUNT(*) FROM imap WHERE transport_id=? AND target='INBOX'",
                    (transport_id,)
                )
                .await?,
            2,
            "multi-device retention preserves nonexpired mail on either relay"
        );
    }
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_relay_policy_smtp_selection_never_uses_strict_relay_for_plaintext() -> Result<()> {
    let (t, strict, mail) = mixed_relays().await?;
    // A reconfigured strict relay is newest, although its row has the lower ID.
    t.sql
        .execute(
            "UPDATE transports SET add_timestamp=100 WHERE id=?",
            (mail,),
        )
        .await?;
    t.sql
        .execute(
            "UPDATE transports SET add_timestamp=200 WHERE id=?",
            (strict,),
        )
        .await?;

    let encrypted: Vec<u32> = eligible_smtp_transports(&t, true)
        .await?
        .into_iter()
        .map(|(id, _)| id)
        .collect();
    assert_eq!(encrypted, vec![strict, mail]);
    let unencrypted: Vec<u32> = eligible_smtp_transports(&t, false)
        .await?
        .into_iter()
        .map(|(id, _)| id)
        .collect();
    assert_eq!(unencrypted, vec![mail]);

    // Policy changes must affect a retry as well as the initial selection.
    set_policy(&t, mail, true).await?;
    assert!(eligible_smtp_transports(&t, false).await?.is_empty());
    assert_eq!(eligible_smtp_transports(&t, true).await?.len(), 2);
    set_policy(&t, strict, false).await?;
    let unencrypted: Vec<u32> = eligible_smtp_transports(&t, false)
        .await?
        .into_iter()
        .map(|(id, _)| id)
        .collect();
    assert_eq!(unencrypted, vec![strict]);
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_relay_policy_first_relay_sync_is_independent_and_ordered() -> Result<()> {
    let (t, strict, mail) = mixed_relays().await?;
    t.sql
        .execute("UPDATE transports SET add_timestamp=100", ())
        .await?;
    let first_relay = "alice@example.org";
    sync_relay_encryption_policies(
        &t,
        &[RelayEncryptionPolicy {
            addr: first_relay.into(),
            force_encryption: false,
            timestamp: 200,
        }],
    )
    .await?;
    assert!(!transport_requires_encryption(&t, strict).await?);
    assert!(!transport_requires_encryption(&t, mail).await?);
    let entered_json: String = t
        .sql
        .query_get_value("SELECT entered_param FROM transports WHERE id=?", (strict,))
        .await?
        .unwrap();
    assert!(!serde_json::from_str::<EnteredLoginParam>(&entered_json)?.force_encryption);

    for (timestamp, expected) in [(199, false), (200, true)] {
        sync_relay_encryption_policies(
            &t,
            &[RelayEncryptionPolicy {
                addr: first_relay.into(),
                force_encryption: true,
                timestamp,
            }],
        )
        .await?;
        assert_eq!(transport_requires_encryption(&t, strict).await?, expected);
    }
    // An explicit subsequent change can allow mail after a concurrent strict tie.
    sync_relay_encryption_policies(
        &t,
        &[RelayEncryptionPolicy {
            addr: first_relay.into(),
            force_encryption: false,
            timestamp: 201,
        }],
    )
    .await?;
    assert!(!transport_requires_encryption(&t, strict).await?);
    sync_relay_encryption_policies(
        &t,
        &[RelayEncryptionPolicy {
            addr: first_relay.into(),
            force_encryption: true,
            timestamp: 202,
        }],
    )
    .await?;
    assert!(transport_requires_encryption(&t, strict).await?);
    assert!(!transport_requires_encryption(&t, mail).await?);
    assert_eq!(
        t.sql
            .query_get_value::<i64>("SELECT add_timestamp FROM transports WHERE id=?", (strict,),)
            .await?,
        Some(100),
        "policy sync does not change the credentials' clock"
    );

    // A late sync message from an old device must not overwrite separate choices.
    for legacy in ["0", "1"] {
        t.sync_config(&Config::ForceEncryption, legacy).await?;
        assert!(transport_requires_encryption(&t, strict).await?);
        assert!(!transport_requires_encryption(&t, mail).await?);
    }
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_relay_policy_reordered_credential_sync_preserves_newer_policy() -> Result<()> {
    let (t, _, mail) = mixed_relays().await?;
    t.sql
        .execute("UPDATE transports SET add_timestamp=100", ())
        .await?;
    let (entered_json, configured_json): (String, String) = t
        .sql
        .query_row(
            "SELECT entered_param, configured_param FROM transports WHERE id=?",
            (mail,),
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .await?;
    let mut entered: EnteredLoginParam = serde_json::from_str(&entered_json)?;
    let mut configured: ConfiguredLoginParamJson = serde_json::from_str(&configured_json)?;
    entered.imap.password = "new-test-password".into();
    configured.imap_password = "new-test-password".into();
    configured.encryption_timestamp = 200;
    let mut snapshot = TransportData {
        entered,
        configured,
        timestamp: 200,
        is_published: true,
    };

    // Policy-only sync arrives before the credentials snapshot it was based on.
    sync_relay_encryption_policies(
        &t,
        &[RelayEncryptionPolicy {
            addr: "alice@mail.example.org".into(),
            force_encryption: true,
            timestamp: 300,
        }],
    )
    .await?;
    sync_transports(&t, std::slice::from_ref(&snapshot), &[]).await?;
    assert!(transport_requires_encryption(&t, mail).await?);
    let (entered_json, configured_json): (String, String) = t
        .sql
        .query_row(
            "SELECT entered_param, configured_param FROM transports WHERE id=?",
            (mail,),
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .await?;
    let entered: EnteredLoginParam = serde_json::from_str(&entered_json)?;
    let configured: ConfiguredLoginParamJson = serde_json::from_str(&configured_json)?;
    assert!(entered.force_encryption);
    assert!(configured.force_encryption);
    assert_eq!(entered.imap.password, "new-test-password");
    assert_eq!(configured.imap_password, "new-test-password");
    assert_eq!(configured.encryption_timestamp, 300);

    // Replaying an even older permissive snapshot cannot roll either part back.
    snapshot.timestamp = 150;
    snapshot.configured.encryption_timestamp = 150;
    snapshot.entered.imap.password = "stale-test-password".into();
    snapshot.configured.imap_password = "stale-test-password".into();
    sync_transports(&t, std::slice::from_ref(&snapshot), &[]).await?;
    assert!(transport_requires_encryption(&t, mail).await?);
    let configured_json: String = t
        .sql
        .query_get_value(
            "SELECT configured_param FROM transports WHERE id=?",
            (mail,),
        )
        .await?
        .unwrap();
    let configured: ConfiguredLoginParamJson = serde_json::from_str(&configured_json)?;
    assert_eq!(configured.imap_password, "new-test-password");
    assert_eq!(configured.encryption_timestamp, 300);
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_relay_policy_old_client_credentials_cannot_reset_mail_permission() -> Result<()> {
    for local_policy_timestamp in [0, -1] {
        let (t, _, mail) = mixed_relays().await?;
        t.sql
            .execute(
                "UPDATE transports SET add_timestamp=100,
             configured_param=json_set(configured_param, '$.encryption_timestamp', ?1)
             WHERE id=?2",
                (local_policy_timestamp, mail),
            )
            .await?;
        let (entered_json, configured_json): (String, String) = t
            .sql
            .query_row(
                "SELECT entered_param, configured_param FROM transports WHERE id=?",
                (mail,),
                |row| Ok((row.get(0)?, row.get(1)?)),
            )
            .await?;
        let mut entered: serde_json::Value = serde_json::from_str(&entered_json)?;
        let mut configured: serde_json::Value = serde_json::from_str(&configured_json)?;
        entered.as_object_mut().unwrap().remove("force_encryption");
        configured
            .as_object_mut()
            .unwrap()
            .remove("force_encryption");
        configured
            .as_object_mut()
            .unwrap()
            .remove("encryption_timestamp");
        entered["imap"]["password"] = "old-client-new-password".into();
        configured["imap_password"] = "old-client-new-password".into();
        let snapshot = TransportData {
            entered: serde_json::from_value(entered)?,
            configured: serde_json::from_value(configured)?,
            timestamp: 200,
            is_published: true,
        };
        sync_transports(&t, &[snapshot], &[]).await?;
        assert!(!transport_requires_encryption(&t, mail).await?);
        let configured_json: String = t
            .sql
            .query_get_value(
                "SELECT configured_param FROM transports WHERE id=?",
                (mail,),
            )
            .await?
            .unwrap();
        let configured: ConfiguredLoginParamJson = serde_json::from_str(&configured_json)?;
        assert_eq!(configured.imap_password, "old-client-new-password");
        assert_eq!(configured.encryption_timestamp, local_policy_timestamp);
    }
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_relay_policy_plaintext_can_be_queued_only_with_mail_relay() -> Result<()> {
    let (t, strict, mail) = mixed_relays().await?;
    set_policy(&t, mail, true).await?;
    let contact = Contact::create(&t, "Bob", "bob@example.net").await?;
    let chat = ChatId::create_for_contact(&t, contact).await?;
    assert!(
        send_text_msg(&t, chat, "Blocked ordinary letter".into())
            .await
            .is_err()
    );
    t.assert_warn("requires end-to-end encryption").await;
    assert_eq!(t.sql.count("SELECT COUNT(*) FROM smtp2", ()).await?, 0);

    set_policy(&t, mail, false).await?;
    assert!(transport_requires_encryption(&t, strict).await?);
    let msg_id = send_text_msg(&t, chat, "Allowed ordinary letter".into()).await?;
    assert_eq!(
        t.sql
            .query_get_value::<bool>("SELECT is_encrypted FROM smtp2 WHERE msg_id=?", (msg_id,))
            .await?,
        Some(false)
    );
    assert_eq!(t.sql.count("SELECT COUNT(*) FROM smtp2", ()).await?, 1);
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_relay_policy_changed_after_queue_does_not_block_later_encrypted_mail() -> Result<()> {
    let (t, _, mail) = mixed_relays().await?;
    let contact = Contact::create(&t, "Ordinary recipient", "recipient@example.net").await?;
    let chat = ChatId::create_for_contact(&t, contact).await?;
    let plain_id = send_text_msg(&t, chat, "Pending ordinary letter".into()).await?;
    let plain_row: i64 = t
        .sql
        .query_get_value("SELECT id FROM smtp2 WHERE msg_id=?", (plain_id,))
        .await?
        .unwrap();

    let bob = TestContext::new_bob().await;
    let encrypted_chat = t.create_chat_id(&bob).await;
    let encrypted_id = send_text_msg(&t, encrypted_chat, "Pending encrypted letter".into()).await?;
    assert_eq!(
        t.sql
            .query_get_value::<bool>(
                "SELECT is_encrypted FROM smtp2 WHERE msg_id=?",
                (encrypted_id,),
            )
            .await?,
        Some(true)
    );

    set_policy(&t, mail, true).await?;
    // With no allowed relay this must fail the old plaintext row locally,
    // without opening any SMTP connection or discarding the next encrypted row.
    send_msg_to_smtp(&t, &mut Smtp::new(), plain_row).await?;
    t.assert_warn("No relay allows unencrypted mail").await;
    assert_eq!(
        Message::load_from_db(&t, plain_id).await?.get_state(),
        MessageState::OutFailed
    );
    assert_eq!(
        t.sql
            .count("SELECT COUNT(*) FROM smtp2 WHERE msg_id=?", (plain_id,))
            .await?,
        0
    );
    assert_eq!(
        t.sql
            .count("SELECT COUNT(*) FROM smtp2 WHERE msg_id=?", (encrypted_id,))
            .await?,
        1
    );
    assert_eq!(
        Message::load_from_db(&t, encrypted_id).await?.get_state(),
        MessageState::OutPending
    );
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_relay_policy_migration_inherits_legacy_value() -> Result<()> {
    for (legacy, expected) in [(None, true), (Some("0"), false), (Some("1"), true)] {
        let t = TestContext::new_alice().await;
        add_pseudo_transport(&t, "alice@mail.example.org").await?;
        t.sql.set_raw_config("force_encryption", legacy).await?;
        // Recreate the two JSON documents as stored by the previous application.
        t.sql
            .execute(
                "UPDATE transports SET
                    entered_param=json_remove(entered_param, '$.force_encryption'),
                    configured_param=json_remove(configured_param, '$.force_encryption')",
                (),
            )
            .await?;
        t.sql.set_raw_config_int("dbversion", 167).await?;
        t.sql.run_migrations(&t).await?;

        let relays = ConfiguredLoginParam::load_all(&t).await?;
        assert_eq!(relays.len(), 2);
        for (id, configured) in relays {
            assert_eq!(configured.force_encryption, expected, "legacy={legacy:?}");
            let entered_json: String = t
                .sql
                .query_get_value("SELECT entered_param FROM transports WHERE id=?", (id,))
                .await?
                .unwrap();
            let entered: EnteredLoginParam = serde_json::from_str(&entered_json)?;
            assert_eq!(entered.force_encryption, expected, "legacy={legacy:?}");
        }
        assert_eq!(all_transports_require_encryption(&t).await?, expected);
    }
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_relay_policy_migration_preserves_explicit_relay_choice() -> Result<()> {
    let (t, strict, mail) = mixed_relays().await?;
    t.sql.set_raw_config("force_encryption", Some("1")).await?;
    t.sql
        .execute(
            "UPDATE transports SET
                entered_param=json_remove(entered_param, '$.force_encryption'),
                configured_param=json_remove(configured_param, '$.force_encryption')
             WHERE id=?",
            (strict,),
        )
        .await?;
    t.sql.set_raw_config_int("dbversion", 167).await?;
    t.sql.run_migrations(&t).await?;
    assert!(transport_requires_encryption(&t, strict).await?);
    assert!(!transport_requires_encryption(&t, mail).await?);
    Ok(())
}

#[test]
fn test_relay_policy_new_and_legacy_json_default_to_encryption() -> Result<()> {
    assert!(EnteredLoginParam::default().force_encryption);
    let mut legacy_entered = serde_json::to_value(EnteredLoginParam::default())?;
    legacy_entered
        .as_object_mut()
        .unwrap()
        .remove("force_encryption");
    let entered: EnteredLoginParam = serde_json::from_value(legacy_entered)?;
    assert!(entered.force_encryption);
    let configured = ConfiguredLoginParam::from_json(
        r#"{"addr":"alice@example.org","imap":[],"imap_user":"","imap_password":"","smtp":[],"smtp_user":"","smtp_password":"","certificate_checks":"Automatic"}"#,
    )?;
    assert!(configured.force_encryption);
    Ok(())
}
