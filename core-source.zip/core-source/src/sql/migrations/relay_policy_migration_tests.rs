//! Regression coverage for accounts predating the transports table.

use anyhow::Result;

use super::STOP_MIGRATIONS_AT;
use crate::login_param::EnteredLoginParam;
use crate::test_utils::TestContext;
use crate::tools::time;
use crate::transport::ConfiguredLoginParam;

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn test_relay_policy_migration_from_130_keeps_recent_ordinary_mail_enabled() -> Result<()> {
    let t = STOP_MIGRATIONS_AT.scope(130, TestContext::new()).await;
    // Before migration 131, login parameters live only in the config table.
    for (key, value) in [
        ("configured", "1"),
        ("configured_addr", "alice@example.org"),
        ("configured_mail_pw", "test-imap-password"),
        ("configured_send_pw", "test-smtp-password"),
        ("configured_imap_servers", "[]"),
        ("configured_smtp_servers", "[]"),
    ] {
        t.sql.set_raw_config(key, Some(value)).await?;
    }
    // Migration 153 recognizes recent mailing-list traffic and enables ordinary
    // mail. Migration 168 must inherit that decision, even though migration 131
    // materialized the relay JSON earlier in the same upgrade.
    t.sql
        .execute(
            "INSERT INTO chats (id,type,name) VALUES (10,140,'Mailing list')",
            (),
        )
        .await?;
    t.sql
        .execute(
            "INSERT INTO msgs (id,rfc724_mid,chat_id,timestamp,type,state,txt)
         VALUES (10,'recent-list@example.net',10,?,10,13,'Recent ordinary mail')",
            (time(),),
        )
        .await?;
    t.sql.run_migrations(&t).await?;
    assert_eq!(
        t.sql.get_raw_config("force_encryption").await?.as_deref(),
        Some("0")
    );
    let configured = ConfiguredLoginParam::load_all(&t).await?;
    assert_eq!(configured.len(), 1);
    assert!(!configured[0].1.force_encryption);
    let entered_json: String = t
        .sql
        .query_get_value("SELECT entered_param FROM transports", ())
        .await?
        .unwrap();
    assert!(!serde_json::from_str::<EnteredLoginParam>(&entered_json)?.force_encryption);
    Ok(())
}
