# native methods
-keep class com.b44t.messenger.** { * ; }

# Keep metadata needed by the JSON parser
-keep class chat.delta.rpc.** { * ; }
-keepattributes *Annotation*,EnclosingMethod,Signature
-keepnames class com.fasterxml.jackson.** { *; }

# bug with video recoder
-keep class com.coremedia.iso.** { *; }

# unused SealedData constructor needed by JsonUtils
-keep class org.thoughtcrime.securesms.crypto.KeyStoreHelper* { *; }

-dontwarn com.google.firebase.analytics.connector.AnalyticsConnector

# Keep WebRTC classes
-keep class org.webrtc.** { *; }
-keepclassmembers class org.webrtc.** { *; }
-keepattributes InnerClasses

# WorkManager-related rules
-keep class * extends androidx.room.RoomDatabase { *; }

# JLatexMath XML tables and alphabet registration resolve these names reflectively.
-keep class org.scilab.forge.jlatexmath.** { *; }
-keep class ru.noties.jlatexmath.awt.Color { *; }

# Markwon's RegistryImpl orders plugins with CorePlugin.class.isAssignableFrom().
# R8 must not merge CorePlugin with our custom plugin: both would be inserted
# first, and CorePlugin would overwrite our newline, HTML and link handlers.
-keep class io.noties.markwon.core.CorePlugin { *; }
