#!/usr/bin/env python3
"""Проверка JSON-поля политики релея с используемым приложением Jackson, без сети."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


def java_tool(name):
    suffix = ".exe" if os.name == "nt" else ""
    home = os.environ.get("JAVA_HOME")
    executable = Path(home) / "bin" / (name + suffix) if home else None
    if executable and executable.is_file():
        return str(executable)
    found = shutil.which(name)
    if not found:
        raise RuntimeError("Не найден " + name)
    return found


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gradle-home", type=Path,
                        default=Path(os.environ.get("GRADLE_USER_HOME", Path.home() / ".gradle")))
    args = parser.parse_args()
    root = Path(__file__).resolve().parent.parent
    jars = []
    for artifact in ["jackson-annotations", "jackson-core", "jackson-databind"]:
        matches = list((args.gradle_home / "caches/modules-2/files-2.1/com.fasterxml.jackson.core" /
                        artifact / "2.11.1").glob("*/*.jar"))
        if len(matches) != 1:
            raise RuntimeError("Сначала загрузите зависимости Gradle: не найден " + artifact)
        jars.extend(matches)
    source = r'''import chat.delta.rpc.types.EnteredLoginParam;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
public class EmailRelayBindingTest {
  public static void main(String[] args) throws Exception {
    ObjectMapper mapper = new ObjectMapper();
    if (!mapper.readValue("{}", EnteredLoginParam.class).forceEncryption) throw new AssertionError("missing");
    if (!mapper.readValue("{\"forceEncryption\":null}", EnteredLoginParam.class).forceEncryption) throw new AssertionError("null");
    if (!mapper.readValue("{\"forceEncryption\":true}", EnteredLoginParam.class).forceEncryption) throw new AssertionError("true");
    EnteredLoginParam[] relays = mapper.readValue("[{\"addr\":\"a@example.org\",\"imapFolder\":\"Chats\",\"forceEncryption\":false},{\"addr\":\"b@example.org\",\"forceEncryption\":true}]", EnteredLoginParam[].class);
    if (relays[0].forceEncryption || !relays[1].forceEncryption) throw new AssertionError("per-relay");
    JsonNode encoded = mapper.valueToTree(relays);
    if (encoded.get(0).get("forceEncryption").asBoolean()) throw new AssertionError("serialized false");
    if (!encoded.get(1).get("forceEncryption").asBoolean()) throw new AssertionError("serialized true");
    if (!encoded.get(0).get("imapFolder").asText().equals("Chats")) throw new AssertionError("folder");
    if (!encoded.get(0).get("addr").asText().equals("a@example.org")) throw new AssertionError("address");
    System.out.println("PASS: 8 relay JSON binding cases");
  }
}
'''
    with tempfile.TemporaryDirectory(prefix="dc-email-relay-binding-") as temporary:
        work = Path(temporary)
        test = work / "EmailRelayBindingTest.java"
        test.write_text(source, encoding="utf-8")
        java = root / "src/main/java/chat/delta/rpc/types"
        classpath = os.pathsep.join(map(str, jars))
        subprocess.run([java_tool("javac"), "-encoding", "UTF-8", "-source", "8", "-target", "8",
                        "-cp", classpath, "-d", str(work), str(java / "EnteredLoginParam.java"),
                        str(java / "EnteredCertificateChecks.java"), str(java / "Socket.java"), str(test)], check=True)
        subprocess.run([java_tool("java"), "-cp", str(work) + os.pathsep + classpath,
                        "EmailRelayBindingTest"], check=True)


if __name__ == "__main__":
    main()
