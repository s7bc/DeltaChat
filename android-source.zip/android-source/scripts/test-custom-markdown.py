#!/usr/bin/env python3
"""JVM-тесты Markdown/TeX без Android SDK; нужны Python 3 и JDK 8 или новее."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import urllib.request
import zipfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work-dir", type=Path, default=Path("build/custom-markdown-tests"))
    args = parser.parse_args()
    project = Path(__file__).resolve().parent.parent
    work = args.work_dir.resolve()
    downloads, dependencies, classes = (work / name for name in ("downloads", "deps", "classes"))
    for directory in (downloads, dependencies, classes):
        directory.mkdir(parents=True, exist_ok=True)
    artifacts = json.loads((project / "scripts/custom-markdown-test-dependencies.json").read_text())
    for artifact in artifacts:
        archive = downloads / artifact["url"].rsplit("/", 1)[1]
        if not archive.is_file():
            data = urllib.request.urlopen(artifact["url"], timeout=90).read()
            if hashlib.sha256(data).hexdigest() != artifact["sha256"]:
                raise RuntimeError("Не совпал SHA-256: " + artifact["name"])
            archive.write_bytes(data)
        if hashlib.sha256(archive.read_bytes()).hexdigest() != artifact["sha256"]:
            raise RuntimeError("Не совпал SHA-256 кэша: " + str(archive))
        target = dependencies / (artifact["name"] + ".jar")
        if archive.suffix == ".aar":
            with zipfile.ZipFile(archive) as package:
                target.write_bytes(package.read("classes.jar"))
        else:
            shutil.copyfile(archive, target)

    def java_tool(name):
        executable = name + (".exe" if os.name == "nt" else "")
        home = os.environ.get("JAVA_HOME")
        if home and (Path(home) / "bin" / executable).is_file():
            return str(Path(home) / "bin" / executable)
        found = shutil.which(name)
        if not found:
            raise RuntimeError("Не найден " + name + "; установите JDK и задайте JAVA_HOME")
        return found

    java, javac = java_tool("java"), java_tool("javac")
    package = Path("org/thoughtcrime/securesms/util/markdown")
    production = [project / "src/main/java" / package / (name + ".java")
                  for name in ("MathSafety", "DollarMathProcessor", "MathTreeSanitizer")]
    tests = sorted((project / "src/test/java" / package).glob("*Test.java"))
    classpath = os.pathsep.join(str(dependencies / (artifact["name"] + ".jar")) for artifact in artifacts)
    subprocess.run([javac, "-encoding", "UTF-8", "-cp", classpath, "-d", str(classes)]
                   + [str(path) for path in production + tests], check=True)
    names = ["org.thoughtcrime.securesms.util.markdown." + path.stem for path in tests]
    subprocess.run([java, "-cp", str(classes) + os.pathsep + classpath,
                    "org.junit.runner.JUnitCore"] + names, check=True)
    print("Проверен JVM-парсер и ограничения TeX. Android UI и APK этим тестом не проверяются.")


if __name__ == "__main__":
    main()
