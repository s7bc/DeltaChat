#!/usr/bin/env python3
"""Проверка разбора email на JVM без Android, сети и внешних зависимостей (JDK 8+)."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile


def java_tool(name):
    executable = name + (".exe" if os.name == "nt" else "")
    home = os.environ.get("JAVA_HOME")
    if home and (Path(home) / "bin" / executable).is_file():
        return str(Path(home) / "bin" / executable)
    found = shutil.which(name)
    if not found:
        raise RuntimeError("Не найден " + name + "; установите JDK и задайте JAVA_HOME")
    return found


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work-dir", type=Path)
    args = parser.parse_args()
    project = Path(__file__).resolve().parent.parent
    cases = []

    def check(name, source, addresses=(), invalid=()):
        cases.append((name, source, list(addresses), list(invalid)))

    check("empty", "")
    check("separators", " ,;\r\n:\t()")
    check("mixed separators", "a@example.org ,;\r\n b@example.org\t:c@example.org😀d@example.org",
          ["a@example.org", "b@example.org", "c@example.org", "d@example.org"])
    address = "a.!#$%&'*+-/=?^_`{|}~@example.org"
    check("local punctuation", address, [address])
    quoted = ['"a b"@example.org', '"a\\"b@c,;"@example.org']
    check("quoted local parts", "\n".join(quoted), quoted)
    check("display names", 'John Doe <john@example.org>; "Иван, Петров" <ivan@пример.рф>',
          ["john@example.org", "ivan@пример.рф"])
    check("case and IDN duplicates", "User@пример.рф user@xn--e1afmkfd.xn--p1ai USER@ПРИМЕР.РФ",
          ["User@пример.рф"])
    literals = ["a@[192.0.2.1]", "a@[IPv6:2001:db8::1]"]
    check("address literals", ";".join(literals), literals)
    malformed = ["a@@example.org", "@example.org", "a@", ".a@example.org", "a..b@example.org",
                 "a.@example.org", "a@-example.org", "a@example_.org", "a@example.org.",
                 "a@example.org!b@example.org", "a@[999.0.0.1]"]
    check("whole malformed list", "; ".join(malformed), invalid=malformed)
    for address in malformed:
        check("no salvaged suffix: " + address, address, invalid=[address])
    check("non-address content", "broken; Good Name <a@example.org> stray",
          ["a@example.org"], ["broken", "stray"])
    check("malformed address before display name", "bad@@example.org <a@example.org>",
          ["a@example.org"], ["bad@@example.org"])
    address = '"broken@example.org; valid@example.org'
    check("unterminated quoted local part", address, invalid=[address])
    for source in ["a@example.org >> b@example.org", "<> a@example.org <> b@example.org",
                   "a@example.org < b@example.org", "<a@example.org b@example.org>",
                   "<a@example.org; <b@example.org"]:
        check("angle delimiters: " + source, source, ["a@example.org", "b@example.org"])
    check("unclosed angle delimiter", "<a@example.org", ["a@example.org"])
    addresses = ["𐐀name@example.org", "user𐐀@example.org"]
    check("supplementary Unicode letters", "😀".join(addresses), addresses)
    check("supplementary case folding", "𐐀@example.org 𐐨@example.org", ["𐐀@example.org"])
    for address in ['"a\nb"@example.org', '"a\tb"@example.org', '"a\x00b"@example.org',
                    '"a\x7fb"@example.org', '"a\\\nb"@example.org', '"a\\яb"@example.org']:
        check("quoted control or invalid escape", address, invalid=[address])
    check("separators inside quotes", '"a:b<>(),;@c"@example.org', ['"a:b<>(),;@c"@example.org'])
    check("numeric domains are not URL IPv4 aliases", "a@127.1 a@127.0.0.1 a@010.000.000.001",
          ["a@127.1", "a@127.0.0.1", "a@010.000.000.001"])
    check("IDNA2003 must not merge distinct domains", "a@faß.de a@fass.de", ["a@faß.de", "a@fass.de"])
    check("canonical IPv6 duplicate", "A@[IPv6:2001:0DB8:0:0:0:0:0:1];a@[IPv6:2001:db8::1]",
          ["A@[IPv6:2001:0DB8:0:0:0:0:0:1]"])
    check("IPv4 embedded IPv6 duplicate", "a@[IPv6:::ffff:192.0.2.1];a@[IPv6:0:0:0:0:0:ffff:c000:201]",
          ["a@[IPv6:::ffff:192.0.2.1]"])
    for address in ["a@[IPv6:2001:::1]", "a@[IPv6:1:2:3]", "a@[IPv6:fe80::1%eth0]",
                    "a@[IPv6:::ffff:999.1.2.3]", "a@[IPv6:example.org]", "a@[1.2.3]",
                    "a@[192.0.2.1", "a@[]", 'a"b"@example.org', '"a"x@example.org']:
        check("invalid literal or quotes: " + address, address, invalid=[address])
    check("ordered deduplication", "B@EXAMPLE.org a@example.org b@example.org A@EXAMPLE.ORG",
          ["B@EXAMPLE.org", "a@example.org"])
    addresses = ["user{}@example.org".format(i) for i in range(1000)]
    check("one thousand addresses", "\r\n".join(addresses), addresses)

    def literal(value):
        # Java допускает JSON-экранирование строк, включая пары UTF-16.
        return json.dumps(value, ensure_ascii=True)

    def array(values):
        return "new String[]{" + ",".join(literal(value) for value in values) + "}"

    source = '''import java.util.Arrays;
import org.thoughtcrime.securesms.util.EmailAddressList;
public class EmailAddressListTest {
  private static int count;
  private static void check(String name, String source, String[] addresses, String[] invalid) {
    EmailAddressList.Result result = EmailAddressList.parse(source);
    if (!result.addresses.equals(Arrays.asList(addresses)) || !result.invalid.equals(Arrays.asList(invalid))) {
      throw new AssertionError(name + "\\naddresses: " + result.addresses + "\\ninvalid: " + result.invalid);
    }
    count++;
  }
  public static void main(String[] args) {
'''
    for name, value, addresses, invalid in cases:
        source += "    check({}, {}, {}, {});\n".format(literal(name), literal(value), array(addresses), array(invalid))
    source += '    System.out.println("PASS: " + count + " email-address parsing cases");\n  }\n}\n'

    def run(work):
        work.mkdir(parents=True, exist_ok=True)
        test = work / "EmailAddressListTest.java"
        test.write_text(source, encoding="utf-8")
        production = project / "src/main/java/org/thoughtcrime/securesms/util/EmailAddressList.java"
        subprocess.run([java_tool("javac"), "-encoding", "UTF-8", "-source", "8", "-target", "8",
                        "-d", str(work), str(production), str(test)], check=True)
        subprocess.run([java_tool("java"), "-cp", str(work), "EmailAddressListTest"], check=True)

    if args.work_dir:
        run(args.work_dir.resolve())
    else:
        with tempfile.TemporaryDirectory(prefix="dc-email-list-tests-") as directory:
            run(Path(directory))
    print("Проверен только разбор списка. Android UI, проверка ядром и доставка писем этим тестом не проверяются.")


if __name__ == "__main__":
    main()
