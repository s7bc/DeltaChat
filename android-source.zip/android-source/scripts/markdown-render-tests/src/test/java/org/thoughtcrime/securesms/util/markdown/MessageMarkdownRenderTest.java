package org.thoughtcrime.securesms.util.markdown;

import static org.junit.Assert.*;
import android.text.Spanned;
import android.widget.TextView;
import io.noties.markwon.core.spans.StrongEmphasisSpan;
import io.noties.markwon.image.AsyncDrawableSpan;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(manifest = Config.NONE, sdk = 33)
public class MessageMarkdownRenderTest {
  private Spanned render(String source) {
    TextView view = new TextView(RuntimeEnvironment.getApplication());
    Spanned text = new MessageMarkdown(view).setText(view, source, false);
    assertEquals(text.toString(), view.getText().toString());
    MessageMarkdown.cancel(view);
    System.out.println("INPUT=" + source.replace("\n", "\\n").replace("\r", "\\r")
        + " OUTPUT=" + text.toString().replace("\n", "\\n").replace("\r", "\\r"));
    return text;
  }
  @Test public void plainEnter() {
    assertEquals("Первая строка\nВторая строка", render("Первая строка\nВторая строка").toString());
  }
  @Test public void boldEnter() {
    Spanned result = render("**Первая строка**\nВторая строка");
    assertEquals("Первая строка\nВторая строка", result.toString());
    assertEquals(1, result.getSpans(0, result.length(), StrongEmphasisSpan.class).length);
  }
  @Test public void windowsEnter() {
    assertEquals("Первая строка\nВторая строка", render("Первая строка\r\nВторая строка").toString());
  }
  @Test public void codeEnter() {
    assertEquals("\u00a0x\u00a0\ny", render("`x`\ny").toString());
    assertTrue(render("```\nx\ny\n```").toString().contains("x\ny"));
  }
  @Test public void formulaEnter() {
    Spanned result = render("Первая\n$x^2$\nПоследняя");
    assertEquals(1, result.getSpans(0, result.length(), AsyncDrawableSpan.class).length);
    String value = result.toString();
    assertTrue(value, value.startsWith("Первая\n"));
    assertTrue(value, value.endsWith("\nПоследняя"));
  }
}
