package io.noties.markwon;
/** Идентификаторы тегов View; при сборке APK их генерирует aapt. */
public final class R {
  public static final class id {
    public static final int markwon_drawables_scheduler = 0x7f010001;
    public static final int markwon_drawables_scheduler_last_text_hashcode = 0x7f010002;
  }
}
