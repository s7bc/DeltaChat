package org.thoughtcrime.securesms.util;
import android.text.style.ClickableSpan;
import android.view.View;
/** Заглушка только для открытия экранов приложения по нажатию на ссылку. */
public final class LongClickCopySpan extends ClickableSpan {
  public LongClickCopySpan(String url) {}
  @Override public void onClick(View view) {}
}
