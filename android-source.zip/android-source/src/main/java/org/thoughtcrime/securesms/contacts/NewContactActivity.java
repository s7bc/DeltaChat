package org.thoughtcrime.securesms.contacts;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import chat.delta.rpc.Rpc;
import chat.delta.rpc.RpcException;
import com.google.android.material.textfield.TextInputEditText;
import java.util.ArrayList;
import java.util.List;
import org.thoughtcrime.securesms.ConversationActivity;
import org.thoughtcrime.securesms.PassphraseRequiredActionBarActivity;
import org.thoughtcrime.securesms.R;
import org.thoughtcrime.securesms.connect.DcHelper;
import org.thoughtcrime.securesms.util.EmailAddressList;
import org.thoughtcrime.securesms.util.EmailRelayPolicy;
import org.thoughtcrime.securesms.util.Util;
import org.thoughtcrime.securesms.util.ViewUtil;

public class NewContactActivity extends PassphraseRequiredActionBarActivity {

  public static final String ADDR_EXTRA = "contact_addr";
  public static final String CONTACT_ID_EXTRA = "contact_id";
  public static final String CONTACT_IDS_EXTRA = "contact_ids";

  private TextInputEditText addrInput;
  private Rpc rpc;
  private int accountId;
  private boolean addingContacts;

  @Override
  protected void onCreate(Bundle state, boolean ready) {
    accountId = DcHelper.getContext(this).getAccountId();
    rpc = DcHelper.getRpc(this);
    setContentView(R.layout.new_contact_activity);

    ActionBar actionBar = getSupportActionBar();
    if (actionBar != null) {
      actionBar.setTitle(R.string.custom_add_by_email);
      actionBar.setDisplayHomeAsUpEnabled(true);
      actionBar.setHomeAsUpIndicator(R.drawable.ic_close_white_24dp);
    }
    ViewUtil.applyWindowInsets(findViewById(R.id.content_container));
    addrInput = ViewUtil.findById(this, R.id.email_text);
    addrInput.setText(getIntent().getStringExtra(ADDR_EXTRA));
  }

  @Override
  public boolean onPrepareOptionsMenu(Menu menu) {
    menu.clear();
    getMenuInflater().inflate(R.menu.new_contact, menu);
    menu.findItem(R.id.menu_create_contact).setEnabled(!addingContacts);
    return super.onPrepareOptionsMenu(menu);
  }

  @Override
  public boolean onOptionsItemSelected(@NonNull MenuItem item) {
    if (item.getItemId() == android.R.id.home) {
      if (!addingContacts) finish();
      return true;
    }
    if (item.getItemId() == R.id.menu_create_contact) {
      addContacts();
      return true;
    }
    return super.onOptionsItemSelected(item);
  }

  private void addContacts() {
    if (addingContacts) return;
    String input = addrInput.getText() == null ? "" : addrInput.getText().toString();
    EmailAddressList.Result parsed = EmailAddressList.parse(input);
    if (!parsed.invalid.isEmpty()) {
      addrInput.setError(getString(R.string.custom_invalid_email_addresses, TextUtils.join(", ", parsed.invalid)));
      return;
    }
    if (parsed.addresses.isEmpty()) {
      addrInput.setError(getString(R.string.login_error_mail));
      return;
    }

    addingContacts = true;
    addrInput.setEnabled(false);
    addrInput.setError(null);
    invalidateOptionsMenu();
    final boolean returnContacts = getCallingActivity() != null;

    Util.runOnAnyBackgroundThread(() -> {
      try {
        List<String> invalid = new ArrayList<>();
        for (String address : parsed.addresses) {
          if (!Boolean.TRUE.equals(rpc.checkEmailValidity(address))) invalid.add(address);
        }
        if (!invalid.isEmpty()) {
          showError(getString(R.string.custom_invalid_email_addresses, TextUtils.join(", ", invalid)));
          return;
        }

        int[] contactIds = new int[parsed.addresses.size()];
        int lastChatId = 0;
        for (int i = 0; i < parsed.addresses.size(); i++) {
          int contactId = rpc.createContact(accountId, parsed.addresses.get(i), null);
          if (contactId == 0) throw new RpcException(getString(R.string.login_error_mail));
          contactIds[i] = contactId;
          // Creating an address-based chat neither sends mail nor starts key exchange.
          lastChatId = rpc.createChatByContactId(accountId, contactId);
          if (lastChatId == 0) throw new RpcException(getString(R.string.error));
        }
        final int openChatId = lastChatId;
        Util.runOnMain(() -> {
          if (isFinishing() || isDestroyed()) return;
          if (returnContacts) {
            Intent result = new Intent();
            result.putExtra(CONTACT_ID_EXTRA, contactIds[0]);
            result.putExtra(CONTACT_IDS_EXTRA, contactIds);
            setResult(RESULT_OK, result);
          } else {
            Intent conversation = new Intent(this, ConversationActivity.class);
            conversation.putExtra(ConversationActivity.CHAT_ID_EXTRA, openChatId);
            conversation.putExtra(ConversationActivity.ACCOUNT_ID_EXTRA, accountId);
            startActivity(conversation);
          }
          finish();
        });
      } catch (RpcException error) {
        showError(EmailRelayPolicy.localizeError(this, error.getMessage()));
      }
    });
  }

  private void showError(String error) {
    Util.runOnMain(() -> {
      if (isFinishing() || isDestroyed()) return;
      addingContacts = false;
      addrInput.setEnabled(true);
      addrInput.setError(error);
      invalidateOptionsMenu();
    });
  }
}
