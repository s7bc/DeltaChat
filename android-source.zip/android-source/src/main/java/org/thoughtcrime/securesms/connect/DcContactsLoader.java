package org.thoughtcrime.securesms.connect;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.b44t.messenger.DcContact;
import com.b44t.messenger.DcContext;
import com.b44t.messenger.DcLot;
import org.thoughtcrime.securesms.search.QrInviteData;
import org.thoughtcrime.securesms.util.AsyncLoader;
import org.thoughtcrime.securesms.util.Util;

public class DcContactsLoader extends AsyncLoader<DcContactsLoader.Ret> {

  private final int listflags;
  private final @Nullable String query;
  private final boolean detectInviteLink;
  private final boolean addScanQRLink;
  private final boolean addCreateGroupLinks;
  private final boolean addCreateContactLink;
  private final boolean blockedContacts;
  private final boolean includeAddressContacts;

  public DcContactsLoader(
      Context context,
      int listflags,
      String query,
      boolean detectInviteLink,
      boolean addCreateGroupLinks,
      boolean addCreateContactLink,
      boolean addScanQRLink,
      boolean blockedContacts) {
    this(context, listflags, query, detectInviteLink, addCreateGroupLinks, addCreateContactLink,
        addScanQRLink, blockedContacts, false);
  }

  public DcContactsLoader(
      Context context,
      int listflags,
      String query,
      boolean detectInviteLink,
      boolean addCreateGroupLinks,
      boolean addCreateContactLink,
      boolean addScanQRLink,
      boolean blockedContacts,
      boolean includeAddressContacts) {
    super(context);
    this.listflags = listflags;
    this.query = (query == null || query.isEmpty()) ? null : query;
    this.detectInviteLink = detectInviteLink;
    this.addScanQRLink = addScanQRLink;
    this.addCreateGroupLinks = addCreateGroupLinks;
    this.addCreateContactLink = addCreateContactLink;
    this.blockedContacts = blockedContacts;
    this.includeAddressContacts = includeAddressContacts;
  }

  @Override
  public @NonNull DcContactsLoader.Ret loadInBackground() {
    DcContext dcContext = DcHelper.getContext(getContext());
    if (blockedContacts) {
      int[] blocked_ids = dcContext.getBlockedContacts();
      return new Ret(blocked_ids, null);
    }

    QrInviteData qrInviteData = null;
    if (detectInviteLink && query != null && query.contains(":")) {
      DcLot qrParsed = dcContext.checkQr(query);
      qrInviteData = QrInviteData.from(getContext(), dcContext, qrParsed, query);
    }

    int[] contact_ids = dcContext.getContacts(listflags, query);
    if (includeAddressContacts && (listflags & DcContext.DC_GCL_ADDRESS) == 0) {
      int[] addressContacts = dcContext.getContacts(
          (listflags | DcContext.DC_GCL_ADDRESS) & ~DcContext.DC_GCL_ADD_SELF, query);
      int[] merged = new int[contact_ids.length + addressContacts.length];
      System.arraycopy(contact_ids, 0, merged, 0, contact_ids.length);
      System.arraycopy(addressContacts, 0, merged, contact_ids.length, addressContacts.length);
      contact_ids = merged;
    }
    int[] additional_items = new int[0];
    if (qrInviteData != null) {
      additional_items = Util.appendInt(additional_items, DcContact.DC_CONTACT_ID_INVITE_LINK);
    }
    if (query == null && addScanQRLink) {
      additional_items = Util.appendInt(additional_items, DcContact.DC_CONTACT_ID_QR_INVITE);
    }
    if (addCreateContactLink) {
      additional_items =
          Util.appendInt(additional_items, DcContact.DC_CONTACT_ID_NEW_CLASSIC_CONTACT);
    }
    if (query == null && addCreateGroupLinks) {
      additional_items = Util.appendInt(additional_items, DcContact.DC_CONTACT_ID_NEW_GROUP);
      additional_items = Util.appendInt(additional_items, DcContact.DC_CONTACT_ID_NEW_BROADCAST);

      if (org.thoughtcrime.securesms.util.EmailRelayPolicy.hasPlainEmailRelay(
          getContext(), dcContext.getAccountId())) {
        additional_items =
            Util.appendInt(additional_items, DcContact.DC_CONTACT_ID_NEW_UNENCRYPTED_GROUP);
      }
    }
    int[] all_ids = new int[contact_ids.length + additional_items.length];
    System.arraycopy(additional_items, 0, all_ids, 0, additional_items.length);
    System.arraycopy(contact_ids, 0, all_ids, additional_items.length, contact_ids.length);
    return new Ret(all_ids, qrInviteData);
  }

  public static class Ret {
    public final int[] ids;
    public final QrInviteData qrInviteData;

    Ret(int[] ids, QrInviteData qrInviteData) {
      this.ids = ids;
      this.qrInviteData = qrInviteData;
    }
  }
}
