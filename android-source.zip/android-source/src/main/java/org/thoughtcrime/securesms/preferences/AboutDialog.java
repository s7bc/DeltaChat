package org.thoughtcrime.securesms.preferences;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import org.thoughtcrime.securesms.R;

public final class AboutDialog {
  private AboutDialog() {}

  public static void show(@NonNull Context context) {
    new AlertDialog.Builder(context)
        .setTitle(R.string.custom_about_title)
        .setMessage(
            AdvancedPreferenceFragment.getVersion(context)
                + "\n\n"
                + context.getString(R.string.custom_about_donation))
        .setPositiveButton(android.R.string.ok, null)
        .show();
  }
}
